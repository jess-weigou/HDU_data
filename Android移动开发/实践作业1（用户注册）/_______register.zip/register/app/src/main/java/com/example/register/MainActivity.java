package com.example.register;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.navigation.NavigationBarView;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;


import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements RadioGroup.OnCheckedChangeListener, CompoundButton.OnCheckedChangeListener {

    String msg = "Android : ";
    String btText = "性别: 男";
    String area = "";
    String account = "";
    String pass = "";
    String hobby1 = "读书";
    String hobby2 = "";
    String hobby3 = "";
    //    Button button = (Button) findViewById(R.id.but1);
    EditText editText1;
    EditText editText2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText1 = findViewById(R.id.edit1);

        editText2 = findViewById(R.id.edit2);

        Spinner myspinner = (Spinner) findViewById(R.id.spinner);
        RadioGroup radioGroup = findViewById(R.id.group);
        radioGroup.setOnCheckedChangeListener(this);
        CheckBox check1 = findViewById(R.id.check1);
        CheckBox check2 = findViewById(R.id.check2);
        CheckBox check3 = findViewById(R.id.check3);
        check1.setOnCheckedChangeListener(this);
        check2.setOnCheckedChangeListener(this);
        check3.setOnCheckedChangeListener(this);
        Log.d(msg, "The onCreate() event");
        myspinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String select_item = parent.getItemAtPosition(position).toString();
                area = select_item;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }

        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(msg, "The onStart() event");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(msg, "The onPause() event");

    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(msg, "The onResume() event");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(msg, "The onStop() event");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(msg, "The onDestroy() event");
    }

    public void startActivity2(View view) {
        account = editText1.getText().toString();
        pass = editText2.getText().toString();
        String info = "账号："+account +"\n"+"密码："+pass+"\n"+btText+"\n"+"地区: "+area+"\n爱好: "+hobby1+" "+hobby2+" "+hobby3+" ";
        Intent intent = new Intent(this, SecondActivity.class);
        Bundle bundle = new Bundle();
        bundle.putString("info", info );

        intent.putExtra("bundle", bundle);
        startActivity(intent);
    }


    @SuppressLint("NonConstantResourceId")
    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        switch (checkedId) {
            case R.id.rb_female:
                btText = "性别：女";
                break;
            case R.id.rb_male:
                btText = "性别：男";
                break;
            default:
                btText = "未选中";
                break;
        }
        Toast.makeText(this, "您选择了" + btText, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

        switch (buttonView.getText().toString()){
            case "读书":
                if (isChecked){
                    hobby1 = "读书";
                }else{
                    hobby1 = "";
                }
                break;
            case "打球":
                if (isChecked){
                    hobby2 = "打球";
                }else{
                    hobby2 = "";
                }
                break;
            case "听音乐":
                if (isChecked){
                    hobby3 = "听音乐";
                }else{
                    hobby3 = "";
                }
                break;
        }


    }
}
