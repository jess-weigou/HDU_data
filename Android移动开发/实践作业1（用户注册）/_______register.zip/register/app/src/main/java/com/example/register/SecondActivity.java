package com.example.register;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {
    String account;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_acticity);
        TextView textView1 = findViewById(R.id.TextView1);
        Intent intent = getIntent();
        Bundle bundleExtra = intent.getBundleExtra("bundle");
        textView1.setText(bundleExtra.getString("info"));

    }

}