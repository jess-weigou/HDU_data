package com.example.fragementtest.model;

public class Person {
    int _id ;
    String staffID;
    String name;
}
