package com.example.fragementtest.model;

public class Schedule {
    public boolean cache;
    public ScheduleData[] data;
    private long error;
    private String msg;


}

