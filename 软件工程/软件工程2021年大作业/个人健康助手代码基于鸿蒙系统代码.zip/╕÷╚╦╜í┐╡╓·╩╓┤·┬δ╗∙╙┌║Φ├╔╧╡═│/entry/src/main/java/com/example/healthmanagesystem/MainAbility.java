package com.example.healthmanagesystem;

import com.example.healthmanagesystem.slice.*;
import ohos.aafwk.ability.fraction.FractionAbility;
import ohos.aafwk.content.Intent;
import ohos.agp.components.StackLayout;
import ohos.agp.components.TabList;

public class MainAbility extends FractionAbility {
    private String[] str = {"首页", "交流",  "我的"};
    private TabList tabList;
    private StackLayout stackLayout;

    @Override
    public void onStart(Intent intent) {
        super.onStart(intent);
        super.setMainRoute(MainAbilitySlice.class.getName());
        super.setUIContent(ResourceTable.Layout_ability_main);
        initView();
    }

    private void initView() {
        tabList = (TabList) findComponentById(ResourceTable.Id_tab_list_bottom);
        for (int i = 0; i < str.length; i++) {
            TabList.Tab tab = tabList.new Tab(getContext());
            tab.setText(str[i]);
            tabList.addTab(tab);
        }
        tabList.setFixedMode(true);
        //默认第一个被选中
        tabList.getTabAt(0).select();
        switchPage(0);
           /* tabList.setTabLength(100); // 设置Tab的宽度
            tabList.setTabMargin(20); // 设置两个Tab之间的间距*/
        tabList.addTabSelectedListener(new TabList.TabSelectedListener() {
            @Override
            public void onSelected(TabList.Tab tab) {
                // 当某个Tab从未选中状态变为选中状态时的回调
                switchPage(tab.getPosition());
            }
            @Override
            public void onUnselected(TabList.Tab tab) {
                // 当某个Tab从选中状态变为未选中状态时的回调

            }
            @Override
            public void onReselected(TabList.Tab tab) {
                // 当某个Tab已处于选中状态，再次被点击时的状态回调

            }
        });
    }

    //模块页面切换
    public  void  switchPage(int  position){
        switch (position){
            case 0:
                getFractionManager()
                        .startFractionScheduler()
                        .replace(ResourceTable.Id_stack_layout, new HomeFraction())
                        .submit();

                break;
            case 1:
                getFractionManager()
                        .startFractionScheduler()
                        .replace(ResourceTable.Id_stack_layout, new CommunityFraction())
                        .submit();


                break;
            case 2:
                getFractionManager()
                        .startFractionScheduler()
                        .replace(ResourceTable.Id_stack_layout, new MedicineFraction())
                        .submit();

                break;
            case 3:
                getFractionManager()
                        .startFractionScheduler()
                        .replace(ResourceTable.Id_stack_layout, new MeFraction())
                        .submit();

                break;
        }
    }

    }


